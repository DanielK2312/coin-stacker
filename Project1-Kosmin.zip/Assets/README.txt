The goal of the game is to hit the moving block with as many coins as posssible.

To move the coin dispense, use "w" to go forward, "a" to go left, "s" to go backward, and "d" to go right.

Every time to coin hits the top of the moving block, the score will increase by one.

Whenever a coin hits the plane, it is destroyed to ensure limited copies of the prefab are in the game scene.